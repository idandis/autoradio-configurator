<?php

namespace App\Http\Controllers;

use App\Models\ConfiguratorProduct;
use Illuminate\Http\RedirectResponse;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Throwable;

class DatabaseMigrationController extends Controller
{
    public function __invoke(): RedirectResponse
    {
        $lock = Cache::lock('admin:database-migration', 300);
        $lockAcquired = false;

        try {
            $lockAcquired = $lock->get();

            if (! $lockAcquired) {
                return back()->withErrors([
                    'database' => 'Un aggiornamento del database è già in corso. Riprova tra qualche minuto.',
                ]);
            }

            $exitCode = Artisan::call('migrate', [
                '--force' => true,
                '--no-interaction' => true,
            ]);

            if ($exitCode !== 0) {
                Log::error('Aggiornamento database fallito dalla dashboard.', [
                    'exit_code' => $exitCode,
                    'output' => Artisan::output(),
                ]);

                return back()->withErrors([
                    'database' => 'Aggiornamento non completato. Controlla i log del server o contatta il provider.',
                ]);
            }

            $this->ensureConfiguratorBodyHtmlColumn();

            if (function_exists('set_time_limit')) {
                @set_time_limit(0);
            }

            foreach (['screen', 'camera', 'speaker', 'accessory'] as $category) {
                foreach (['it' => 'italiani', 'en' => 'inglesi'] as $locale => $label) {
                    if ($error = $this->importMissingDescriptions($category, $locale, $label)) {
                        return back()->withErrors(['database' => $error]);
                    }
                    if ($error = $this->importMissingTranslations($category, $locale, $label)) {
                        return back()->withErrors(['database' => $error]);
                    }
                }
            }

            $this->clearApplicationCaches();

            $opcacheReset = function_exists('opcache_reset') && @opcache_reset();
            $translatedItalianTitles = ConfiguratorProduct::query()
                ->whereIn('category', ['screen', 'camera', 'speaker', 'accessory'])->whereNotNull('title_it')->count();
            $translatedEnglishTitles = ConfiguratorProduct::query()
                ->whereIn('category', ['screen', 'camera', 'speaker', 'accessory'])->whereNotNull('title_en')->count();
            $translatedItalianDescriptions = ConfiguratorProduct::query()
                ->whereIn('category', ['screen', 'camera', 'speaker', 'accessory'])->whereNotNull('body_html_it')->count();
            $translatedEnglishDescriptions = ConfiguratorProduct::query()
                ->whereIn('category', ['screen', 'camera', 'speaker', 'accessory'])->whereNotNull('body_html_en')->count();
            $status = 'Database e cache Laravel aggiornati correttamente.';
            $status .= " Titoli tradotti: {$translatedItalianTitles} italiani e {$translatedEnglishTitles} inglesi.";
            $status .= " Descrizioni tradotte: {$translatedItalianDescriptions} italiane e {$translatedEnglishDescriptions} inglesi.";

            if ($opcacheReset) {
                $status .= ' Anche la cache PHP OPcache è stata svuotata.';
            } else {
                $status .= ' OPcache non è gestibile dall’app: se continui a vedere la versione precedente, riavvia PHP dal pannello hosting.';
            }

            return back()->with('status', $status);
        } catch (Throwable $exception) {
            Log::error('Errore durante l’aggiornamento database dalla dashboard.', [
                'exception' => $exception,
            ]);

            return back()->withErrors([
                'database' => 'Impossibile aggiornare il database: '.$this->safeErrorMessage($exception),
            ]);
        } finally {
            if ($lockAcquired) {
                $lock->release();
            }
        }
    }

    private function importMissingTranslations(string $category, string $locale, string $label): ?string
    {
        $missing = ConfiguratorProduct::query()
            ->where('category', $category)
            ->where(fn ($query) => $query->whereNull('title_'.$locale)->orWhere('title_'.$locale, ''))
            ->count();

        if ($missing === 0) {
            return null;
        }

        $exitCode = Artisan::call('configurator:translate-titles', [
            'locale' => $locale,
            '--category' => $category,
            '--no-interaction' => true,
        ]);

        if ($exitCode === 0) {
            return null;
        }

        $output = trim(Artisan::output());
        Log::error("Traduzione titoli {$label} della categoria {$category} fallita dalla dashboard.", [
            'exit_code' => $exitCode,
            'output' => $output,
        ]);

        return "Database aggiornato, ma la traduzione dei titoli {$label} della categoria {$category} non è terminata"
            .($output !== '' ? ': '.$output : '.');
    }

    private function importMissingDescriptions(string $category, string $locale, string $label): ?string
    {
        if (! is_file(resource_path("data/{$category}-descriptions-{$locale}.json"))) {
            return null;
        }

        $missing = ConfiguratorProduct::query()->where('category', $category)
            ->whereNotNull('body_html')->where('body_html', '!=', '')
            ->where(fn ($query) => $query->whereNull('body_html_'.$locale)->orWhere('body_html_'.$locale, ''))
            ->count();
        if ($missing === 0) {
            return null;
        }

        $exitCode = Artisan::call('configurator:translate-descriptions', [
            'locale' => $locale,
            '--category' => $category,
            '--catalog-only' => true,
            '--no-interaction' => true,
        ]);
        if ($exitCode === 0) {
            return null;
        }

        Log::error("Import descrizioni {$label} della categoria {$category} fallito dalla dashboard.", [
            'exit_code' => $exitCode,
            'output' => Artisan::output(),
        ]);
        return "Database aggiornato, ma l’importazione delle descrizioni {$label} della categoria {$category} non è terminata.";
    }

    private function clearApplicationCaches(): void
    {
        foreach (['config:clear', 'route:clear', 'view:clear', 'event:clear'] as $command) {
            $exitCode = Artisan::call($command, ['--no-interaction' => true]);

            if ($exitCode !== 0) {
                Log::warning('Pulizia cache Laravel non completata dalla dashboard.', [
                    'command' => $command,
                    'exit_code' => $exitCode,
                    'output' => Artisan::output(),
                ]);
            }
        }
    }

    private function ensureConfiguratorBodyHtmlColumn(): void
    {
        if (Schema::hasColumn('configurator_products', 'body_html')) {
            return;
        }

        Schema::table('configurator_products', function (Blueprint $table): void {
            $table->longText('body_html')->nullable()->after('title_en');
        });
    }

    private function safeErrorMessage(Throwable $exception): string
    {
        $message = preg_replace('/\s+/', ' ', $exception->getMessage()) ?: 'errore sconosciuto';

        return Str::limit($message, 350);
    }
}
