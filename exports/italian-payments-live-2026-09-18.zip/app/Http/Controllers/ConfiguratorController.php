<?php

namespace App\Http\Controllers;

use App\Models\ConfiguratorProduct;
use App\Models\InstallationZone;
use App\Models\MissingVehicleRequest;
use App\Models\SharedConfiguration;
use App\Services\ItalianCheckout;
use App\Services\VehicleImageResolver;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Inertia\Response;

class ConfiguratorController extends Controller
{
    private const STANDARD_CAMERA_HANDLES = [
        'camara-trasera-estandar',
        'camara-trasera-frontal-ahd-1080p-gran-angular-con-vision-nocturna',
        'camara-360-para-radios-de-coche-android-con-vista-de-ave',
    ];

    public function missingVehicle(Request $request)
    {
        $data = $request->validate([
            'first_name' => ['required', 'string', 'max:100'],
            'last_name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['required', 'string', 'max:50'],
            'province' => ['required', 'string', 'max:100'],
            'brand' => ['required', 'string', 'max:100'],
            'model' => ['required', 'string', 'max:255'],
            'year' => ['required', 'integer', 'between:1900,2100'],
            'comment' => ['nullable', 'string', 'max:5000'],
            'photo' => ['nullable', 'image', 'max:2048'],
        ]);

        $photo = $request->file('photo');
        $photoPath = $photo?->store('missing-vehicle-requests', 'public');
        $storedPhotoPath = $photoPath ? Storage::disk('public')->path($photoPath) : null;
        MissingVehicleRequest::create([...$data, 'photo_path' => $photoPath]);
        unset($data['photo']);
        $body = view('emails.missing-vehicle-request', ['requestData' => $data])->render();

        try {
            Mail::html($body, function ($message) use ($data, $photo, $storedPhotoPath) {
                $message
                    ->to(config('mail.notification_to'))
                    ->replyTo($data['email'], $data['first_name'].' '.$data['last_name'])
                    ->subject('Nuova richiesta autoradio: '.$data['brand'].' '.$data['model']);

                if ($photo && $storedPhotoPath) {
                    $message->attach($storedPhotoPath, [
                        'as' => $photo->getClientOriginalName(),
                        'mime' => $photo->getMimeType(),
                    ]);
                }
            });
        } catch (\Throwable $exception) {
            report($exception);

            return response()->json(['message' => 'Errore SMTP: '.$exception->getMessage()], 500);
        }

        return response()->json(['message' => 'ok']);
    }

    public function __invoke(Request $request, VehicleImageResolver $vehicleImageResolver): Response
    {
        $sharedConfiguration = $this->sharedConfiguration($request);
        $requiredCustomKeys = collect($sharedConfiguration['customProducts'] ?? [])
            ->merge($request->query('summary') === '1' ? (array) $request->query('custom', []) : [])
            ->filter(fn ($key) => is_string($key))
            ->unique()
            ->values();
        $requiredCustomProductIds = $requiredCustomKeys
            ->filter(fn (string $key) => str_starts_with($key, 'product-'))
            ->map(fn (string $key) => (int) substr($key, 8))
            ->filter();
        $requiredCustomVariantIds = $requiredCustomKeys
            ->filter(fn (string $key) => str_starts_with($key, 'variant-'))
            ->map(fn (string $key) => (int) substr($key, 8))
            ->filter();
        $requiredCustomProducts = $requiredCustomKeys->isEmpty()
            ? collect()
            : ConfiguratorProduct::with('variants')
                ->whereIn('category', ['screen', 'camera', 'speaker'])
                ->where(function ($query) use ($requiredCustomProductIds, $requiredCustomVariantIds) {
                    $query->whereIn('id', $requiredCustomProductIds)
                        ->orWhereHas('variants', fn ($variants) => $variants->whereIn('id', $requiredCustomVariantIds));
                })
                ->orderBy('category')
                ->orderBy('title')
                ->get();

        $screenProducts = ConfiguratorProduct::query()
            ->select(['id', 'brand', 'model', 'year_from', 'year_to'])
            ->where('category', 'screen')
            ->whereNotNull('brand')
            ->where('brand', '!=', '')
            ->whereNotNull('model')
            ->where('model', '!=', '')
            ->whereRaw('LOWER(TRIM(model)) != ?', ['universal'])
            ->whereNotNull('year_from')
            ->whereNotNull('year_to')
            ->orderBy('brand')
            ->orderBy('model')
            ->get();

        $sharedScreenHandles = collect($sharedConfiguration['screens'] ?? [])
            ->pluck('product')
            ->merge($request->query('summary') === '1' ? (array) $request->query('product', []) : [])
            ->filter(fn ($handle) => is_string($handle) && $handle !== '')
            ->unique()
            ->values();
        $initialScreenProducts = $sharedScreenHandles->isEmpty()
            ? collect()
            : ConfiguratorProduct::with('variants')
                ->where('category', 'screen')
                ->whereIn('handle', $sharedScreenHandles)
                ->get();

        $universalScreenProducts = $initialScreenProducts
            ->filter(fn (ConfiguratorProduct $product) => mb_strtolower(trim((string) $product->model)) === 'universal')
            ->filter(fn (ConfiguratorProduct $product) => in_array(
                preg_replace('/\s+/u', '', mb_strtoupper((string) ($product->meta['din'] ?? ''))),
                ['1DIN', '2DIN'],
                true,
            ))
            ->values();
        $initialSpecificScreenProducts = $initialScreenProducts
            ->reject(fn (ConfiguratorProduct $product) => mb_strtolower(trim((string) $product->model)) === 'universal')
            ->values();

        $cameraProducts = ConfiguratorProduct::query()
            ->select(['id', 'handle', 'brand', 'model', 'year_from', 'year_to'])
            ->where('category', 'camera')
            ->orderBy('price_min')
            ->get()
            ->values();

        $installationZones = InstallationZone::query()
            ->where('active', true)
            ->with(['postalCodes', 'services'])
            ->orderBy('name')
            ->get();
        $vehicleOptions = $this->screenOptions($initialSpecificScreenProducts);
        $vehicleCompatibility = $screenProducts
            ->merge($cameraProducts->reject(fn (ConfiguratorProduct $product) => in_array($product->handle, self::STANDARD_CAMERA_HANDLES, true)))
            ->map(function (ConfiguratorProduct $product) {
                $vehicleFields = $this->vehicleFields($product);

                return [
                    'brand' => $vehicleFields['brand'],
                    'model' => $vehicleFields['model'],
                    'yearFrom' => $product->year_from,
                    'yearTo' => $product->year_to,
                ];
            })
            ->unique(fn (array $vehicle) => implode('|', $vehicle))
            ->values();
        $cameraOptions = [];
        $vehicleImageFilenames = $vehicleImageResolver->imageFilenames();
        $vehicleImageMappingOptions = [
            ...$vehicleCompatibility->map(fn (array $vehicle) => [
                'brand' => $vehicle['brand'],
                'model' => $vehicle['model'],
                'yearFrom' => $vehicle['yearFrom'],
                'yearTo' => $vehicle['yearTo'],
            ])->all(),
        ];
        $vehicleImageMappingKey = 'configurator:vehicle-image-mappings:v2:'.hash('sha256', serialize([
            $vehicleImageMappingOptions,
            $vehicleImageFilenames,
            @filemtime(resource_path('data/vehicle-image-generations.json')) ?: 0,
        ]));
        $vehicleImageMappings = Cache::remember(
            $vehicleImageMappingKey,
            now()->addDay(),
            fn () => $vehicleImageResolver->mappings($vehicleImageMappingOptions, $vehicleImageFilenames),
        );

        return Inertia::render('Configurator', [
            'italianCheckoutEnabled' => ItalianCheckout::availableForRequest($request),
            'italianCheckoutIsTest' => ! \App\Services\StripePayments::live(),
            'locale' => app()->getLocale(),
            'translations' => trans('configurator'),
            'sharedConfiguration' => $sharedConfiguration,
            'customProducts' => $this->customProductOptions($requiredCustomProducts)
                ->filter(fn (array $product) => $requiredCustomKeys->contains($product['key']))
                ->values(),
            'vehicles' => $vehicleOptions,
            'vehicleCompatibility' => $vehicleCompatibility,
            'universalScreens' => $this->screenOptions($universalScreenProducts),
            'cameraOptions' => $cameraOptions,
            'speakerOptions' => [],
            'installationOptions' => $installationZones->flatMap(fn (InstallationZone $zone) => $zone->services->map(fn ($service) => [
                'key' => 'zone-service-'.$service->id,
                'productId' => null,
                'variantId' => null,
                'title' => $service->localizedName(),
                'sourceTitle' => $service->name,
                'productTitle' => $service->localizedName(),
                'variantTitle' => null,
                'price' => (float) $service->price,
                'shopifyVariantId' => null,
                'sku' => null,
                'subtype' => 'zone-service',
                'location' => $zone->name,
                'installationRaw' => null,
            ])
            )->values(),
            'installationZones' => $installationZones
                ->map(fn (InstallationZone $zone) => [
                    'id' => $zone->id,
                    'name' => $zone->name,
                    'installerAddress' => $zone->installer_address,
                    'installerPhone' => $zone->installer_phone,
                    'postalRanges' => $zone->postalCodes->map(fn ($range) => [
                        'from' => $range->postal_code_from,
                        'to' => $range->postal_code_to,
                    ])->values(),
                    'productHandles' => $zone->services->map(fn ($service) => 'zone-service-'.$service->id)->values(),
                    'productPrices' => $zone->services->mapWithKeys(fn ($service) => ['zone-service-'.$service->id => (float) $service->price]),
                    'productTitles' => $zone->services->mapWithKeys(fn ($service) => ['zone-service-'.$service->id => $service->localizedName()]),
                ])->values(),
            'vehicleImageMappings' => $vehicleImageMappings,
            'brandImages' => collect(glob(public_path('images/brands/*.{png,jpg,jpeg,webp}'), GLOB_BRACE) ?: [])
                ->map(fn (string $path) => basename($path))
                ->sort()
                ->values(),
        ]);
    }

    public function customProducts(): JsonResponse
    {
        $products = ConfiguratorProduct::with('variants')
            ->whereIn('category', ['screen', 'camera', 'speaker'])
            ->orderBy('category')
            ->orderBy('title')
            ->get();

        return response()->json(['products' => $this->customProductOptions($products)]);
    }

    public function specificScreens(Request $request, VehicleImageResolver $vehicleImageResolver): JsonResponse
    {
        $data = $request->validate([
            'brand' => ['required', 'string', 'max:255'],
            'model' => ['required', 'string', 'max:255'],
            'year' => ['required', 'integer', 'between:1900,2100'],
        ]);

        $products = ConfiguratorProduct::with('variants')
            ->where('category', 'screen')
            ->whereRaw('LOWER(TRIM(model)) != ?', ['universal'])
            ->where('year_from', '<=', $data['year'])
            ->where('year_to', '>=', $data['year'])
            ->orderBy('brand')
            ->orderBy('model')
            ->get()
            ->filter(function (ConfiguratorProduct $product) use ($data, $vehicleImageResolver) {
                $vehicle = $this->vehicleFields($product);

                return collect($vehicleImageResolver->vehicleEntries($vehicle['brand'], $vehicle['model']))
                    ->contains(fn (array $entry) => Str::slug($entry['brand']) === Str::slug($data['brand'])
                        && Str::slug($entry['model']) === Str::slug($data['model'])
                    );
            })
            ->values();

        return response()->json(['products' => $this->screenOptions($products)]);
    }

    public function universalScreens(Request $request): JsonResponse
    {
        $data = $request->validate([
            'din' => ['required', 'in:1DIN,2DIN'],
        ]);

        $products = ConfiguratorProduct::with('variants')
            ->where('category', 'screen')
            ->whereRaw('LOWER(TRIM(model)) = ?', ['universal'])
            ->orderBy('price_min')
            ->get()
            ->filter(fn (ConfiguratorProduct $product) => preg_replace('/\s+/u', '', mb_strtoupper((string) ($product->meta['din'] ?? ''))) === $data['din']
            )
            ->values();

        return response()->json(['products' => $this->screenOptions($products)]);
    }

    public function cameras(Request $request, VehicleImageResolver $vehicleImageResolver): JsonResponse
    {
        $data = $request->validate([
            'mode' => ['required', 'in:specific,universal'],
            'brand' => ['nullable', 'string', 'max:255'],
            'model' => ['nullable', 'string', 'max:255'],
            'year' => ['nullable', 'integer', 'between:1900,2100'],
        ]);
        $hasVehicle = $data['mode'] === 'specific'
            && filled($data['brand'] ?? null)
            && filled($data['model'] ?? null)
            && isset($data['year']);

        $products = ConfiguratorProduct::with('variants')
            ->where('category', 'camera')
            ->where(function ($query) use ($data, $hasVehicle) {
                $query->whereIn('handle', self::STANDARD_CAMERA_HANDLES);
                if ($hasVehicle) {
                    $query->orWhere(function ($specific) use ($data) {
                        $specific->where('year_from', '<=', $data['year'])
                            ->where('year_to', '>=', $data['year']);
                    });
                }
            })
            ->orderBy('price_min')
            ->get()
            ->filter(function (ConfiguratorProduct $product) use ($data, $hasVehicle, $vehicleImageResolver) {
                if (in_array($product->handle, self::STANDARD_CAMERA_HANDLES, true)) {
                    return true;
                }
                if (! $hasVehicle) {
                    return false;
                }

                $vehicle = $this->vehicleFields($product);

                return collect($vehicleImageResolver->vehicleEntries($vehicle['brand'], $vehicle['model']))
                    ->contains(fn (array $entry) => Str::slug($entry['brand']) === Str::slug($data['brand'])
                        && Str::slug($entry['model']) === Str::slug($data['model'])
                    );
            })
            ->values();

        return response()->json(['products' => $this->cameraOptions($products)]);
    }

    public function speakers(): JsonResponse
    {
        $products = ConfiguratorProduct::with('variants')
            ->where('category', 'speaker')
            ->orderBy('title')
            ->get();

        return response()->json(['products' => $this->speakerOptions($products)]);
    }

    private function customProductOptions($products)
    {
        return $products->flatMap(function (ConfiguratorProduct $product) {
            $variants = $product->variants->filter(
                fn ($variant) => $variant->price !== null || filled($variant->shopify_variant_id),
            );

            if ($variants->isEmpty()) {
                return [[
                    'key' => 'product-'.$product->id,
                    'productId' => $product->id,
                    'variantId' => null,
                    'title' => $product->localizedTitle(),
                    'variantTitle' => null,
                    'category' => $product->category,
                    'sku' => null,
                    'shopifyVariantId' => null,
                    'price' => (float) ($product->price_min ?? 0),
                    'image' => $product->image_url,
                    'brand' => $product->brand,
                    'model' => $product->model,
                    'yearFrom' => $product->year_from,
                    'yearTo' => $product->year_to,
                ]];
            }

            return $variants->map(fn ($variant) => [
                'key' => 'variant-'.$variant->id,
                'productId' => $product->id,
                'variantId' => $variant->id,
                'title' => $product->localizedTitle(),
                'variantTitle' => $variant->option_value ?: $variant->title,
                'category' => $product->category,
                'sku' => $variant->sku,
                'shopifyVariantId' => $variant->shopify_variant_id,
                'price' => (float) ($variant->price ?? $product->price_min ?? 0),
                'image' => $variant->image_url ?: $product->image_url,
                'brand' => $product->brand,
                'model' => $product->model,
                'yearFrom' => $product->year_from,
                'yearTo' => $product->year_to,
            ]);
        })->values();
    }

    private function screenOptions($products)
    {
        return $products->map(function (ConfiguratorProduct $product) {
            $vehicleFields = $this->vehicleFields($product);

            return [
                'id' => $product->id,
                'handle' => $product->handle,
                'title' => $product->localizedTitle(),
                'brand' => $vehicleFields['brand'],
                'model' => $vehicleFields['model'],
                'yearFrom' => $product->year_from,
                'yearTo' => $product->year_to,
                'din' => ($din = preg_replace('/\s+/u', '', mb_strtoupper((string) ($product->meta['din'] ?? '')))) !== ''
                    ? $din
                    : null,
                'image' => $product->image_url,
                'originalDashboardImages' => $product->meta['original_dashboard_images'] ?? [],
                'variants' => $product->variants
                    ->filter(fn ($variant) => filled($variant->option_value))
                    ->groupBy(fn ($variant) => mb_strtolower(trim((string) $variant->option_value)))
                    ->map(function ($matchingVariants) use ($product) {
                        $choices = $matchingVariants->map(fn ($variant) => [
                            'id' => $variant->id,
                            'title' => $variant->option_value,
                            'color' => filled($variant->meta['option2'] ?? null)
                                ? trim((string) $variant->meta['option2'])
                                : null,
                            'sku' => $variant->sku,
                            'shopifyVariantId' => $variant->shopify_variant_id,
                            'price' => (float) $variant->price,
                            'image' => $variant->image_url ?: $product->image_url,
                            'dashboardVariant' => $this->variantSuffix($variant->option_value ?: $variant->title),
                        ])->values();
                        $default = $choices->first();

                        return [
                            ...$default,
                            'colorOptions' => $choices->filter(fn ($choice) => filled($choice['color']))->values(),
                        ];
                    })
                    ->sortBy('price')
                    ->values(),
            ];
        })->values();
    }

    private function variantSuffix(?string $title): ?string
    {
        preg_match('/(?:^|[\s_-])([a-z])\s*$/iu', trim((string) $title), $matches);

        return isset($matches[1]) ? mb_strtoupper($matches[1]) : null;
    }

    private function sharedConfiguration(Request $request): ?array
    {
        $uuid = $request->string('c')->toString();

        if (! Str::isUuid($uuid)) {
            return null;
        }

        return SharedConfiguration::query()
            ->where('uuid', $uuid)
            ->first()
            ?->configuration;
    }

    /** @return array{brand: ?string, model: ?string} */
    private function vehicleFields(ConfiguratorProduct $product): array
    {
        if (preg_match('/(?:^|\|)\s*\d+\s*[:：]/u', (string) $product->model)) {
            return ['brand' => $product->brand, 'model' => $product->model];
        }

        static $multibrandEntries = null;
        $multibrandEntries ??= require config_path('vehicle-multibrand.php');
        $entries = $multibrandEntries[$product->id] ?? [];
        if (! is_array($entries) || $entries === []) {
            return ['brand' => $product->brand, 'model' => $product->model];
        }

        $brands = collect($entries)->pluck('brand')->filter()->unique()->values();
        $models = collect($entries)
            ->filter(fn ($entry) => is_array($entry) && isset($entry['brand'], $entry['model']))
            ->map(function (array $entry) use ($brands) {
                $brandIndex = $brands->search($entry['brand']);

                return $brandIndex === false ? null : ($brandIndex + 1).':'.$entry['model'];
            })
            ->filter()
            ->unique()
            ->values();

        return [
            'brand' => $brands->implode(' | '),
            'model' => $models->implode(' | '),
        ];
    }

    private function cameraOptions($products): array
    {
        $options = [];

        foreach ($products as $product) {
            $cameraVariants = $product->variants
                ->filter(fn ($variant) => $variant->price !== null || filled($variant->shopify_variant_id))
                ->sortBy('price')
                ->values();
            $defaultVariant = $cameraVariants->first();
            $variantOptions = $cameraVariants->map(fn ($variant) => [
                'id' => $variant->id,
                'title' => $variant->option_value ?: $variant->title,
                'color' => null,
                'sku' => $variant->sku,
                'shopifyVariantId' => $variant->shopify_variant_id,
                'price' => (float) ($variant->price ?? $product->price_min),
                'image' => $variant->image_url ?: $product->image_url,
            ])->values();

            $options[] = [
                'key' => $product->handle,
                'productHandle' => $product->handle,
                'productId' => $product->id,
                'variantId' => $defaultVariant?->id,
                'title' => $product->handle === 'camara-360-para-radios-de-coche-android-con-vista-de-ave'
                    ? trans('configurator.camera.standard_360')
                    : $product->localizedTitle(),
                'productTitle' => $product->localizedTitle(),
                'variantTitle' => $defaultVariant?->option_value ?: $defaultVariant?->title,
                'price' => (float) ($defaultVariant?->price ?? $product->price_min),
                'image' => $product->image_url,
                'shopifyVariantId' => $defaultVariant?->shopify_variant_id,
                'sku' => $defaultVariant?->sku,
                'variants' => $variantOptions,
                'isStandard' => in_array($product->handle, [
                    'camara-trasera-estandar',
                    'camara-trasera-frontal-ahd-1080p-gran-angular-con-vision-nocturna',
                    'camara-360-para-radios-de-coche-android-con-vista-de-ave',
                ], true),
                'isStandardFront' => $product->handle === 'camara-trasera-frontal-ahd-1080p-gran-angular-con-vision-nocturna',
                'isFront' => $product->handle === 'camara-trasera-frontal-ahd-1080p-gran-angular-con-vision-nocturna' || $product->subtype === 'front',
                'isRear' => $product->handle !== 'camara-360-para-radios-de-coche-android-con-vista-de-ave' &&
                    ($product->handle === 'camara-trasera-estandar'
                    || $product->subtype === 'rear'
                    || ($product->subtype === 'ahd' && preg_match('/traser|rear/', mb_strtolower($product->title)) === 1)),
                'brand' => $product->brand,
                'model' => $product->model,
                'yearFrom' => $product->year_from,
                'yearTo' => $product->year_to,
            ];
        }

        return $options;
    }

    private function speakerOptions($products): array
    {
        return $products
            ->groupBy(fn (ConfiguratorProduct $product) => mb_strtolower(trim($product->title)))
            ->map(function ($matchingProducts) {
                /** @var ConfiguratorProduct $product */
                $product = $matchingProducts->first();
                $variant = $matchingProducts
                    ->flatMap(fn (ConfiguratorProduct $matchingProduct) => $matchingProduct->variants)
                    ->filter(fn ($candidate) => filled($candidate->shopify_variant_id) && $candidate->price !== null)
                    ->sortBy('price')
                    ->first();

                if (! $variant) {
                    return null;
                }

                $sizes = $matchingProducts
                    ->flatMap(fn (ConfiguratorProduct $matchingProduct) => $matchingProduct->meta['speaker_sizes'] ?? [])
                    ->map(fn ($size) => trim((string) $size))
                    ->filter()
                    ->unique()
                    ->values()
                    ->all();

                $categories = $matchingProducts
                    ->flatMap(fn (ConfiguratorProduct $matchingProduct) => $matchingProduct->meta['speaker_categories'] ?? [])
                    ->map(fn ($category) => trim((string) $category))
                    ->filter()
                    ->unique(fn ($category) => mb_strtolower($category))
                    ->values()
                    ->all();

                return [
                    'key' => 'speaker-'.$variant->id,
                    'productId' => $variant->configurator_product_id,
                    'variantId' => $variant->id,
                    'handle' => $product->handle,
                    'title' => $product->localizedTitle(),
                    'productTitle' => $product->localizedTitle(),
                    'variantTitle' => $variant->option_value ?: $variant->title,
                    'price' => (float) $variant->price,
                    'image' => $product->image_url ?: $variant->image_url,
                    'shopifyVariantId' => $variant->shopify_variant_id,
                    'sku' => $variant->sku,
                    'sizes' => $sizes,
                    'categories' => $categories,
                    'brand' => $product->brand,
                    'model' => $product->model,
                    'yearFrom' => $product->year_from,
                    'yearTo' => $product->year_to,
                ];
            })
            ->filter()
            ->sortBy('price')
            ->values()
            ->all();
    }
}
