export const store = () => '/login';
