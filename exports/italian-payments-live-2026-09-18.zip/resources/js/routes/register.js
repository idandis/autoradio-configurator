export const store = () => '/register';
